$(function(){
	template.config("escape", false); 
	LoadData();
})

var pageNumber=1;//当前页码
var pageSize=6;//每页多少条
var maxcount; //总条数
var totalPage; //总页数

function LoadData(){
	ArticleType=gp.request.ArticleType;
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleList", {ArticleType:ArticleType, pageNumber:pageNumber, pageSize:pageSize}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {				
				if (data.list && data.list.length > 0) {
					maxcount=data.list[0].maxcount;
					totalPage = Math.ceil(maxcount / pageSize);
					BindIndustryDom(data.list);
				}
			}
	
		}
		InitHomeCss();
		page();
	});
	
}

function page(){
	//分页
	$("#page").paging({
		pageNo: pageNumber,//当前页码
		totalPage: totalPage,//总页数
		totalSize: maxcount, //总条数
		callback: function(num) {
			pageNumber=num;
			LoadData();
		}
	})
}

/**
 * 政策解读列表开始
 * @param {array 产业报告} industrylists 
 */
function BindIndustryDom(zcjdlist) {
	var template_html="";
	template_html = template("zcjd_list_template", { zcjdlist: zcjdlist });
	$('#zcjd_list_dom').html(template_html);
}

/** 
 * 初始化页面 Css 样式
*/
function InitHomeCss(){
	//政策解读图文
    $('.zcjd_list li').hover(function(){
    	$(this).stop().animate({
			bottom:'5',
		},300);
		$('.dixian',this).stop().css('height','3px');
		$('.dixian',this).stop().animate({
			left:'0',
			width:'100%',
			right:'0'
		},300);
		$(this).css("box-shadow", "0 0 10px 1px #ddd");
	},function(){
		$(this).css("box-shadow", "0 0 0");
    	$(this).stop().animate({
			bottom:'0',
		},300);
		$('.dixian',this).stop().animate({
			left:'0',
			width:'0'
		},300);
	});
	
	//控制标题文字多少
	$(".zcjd_list_nr h3").each(function(){
		var maxwidth=14;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
	//控制内容文字多少
	$(".zcjd_list_nr div").each(function(){
		var maxwidth=45;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
}



