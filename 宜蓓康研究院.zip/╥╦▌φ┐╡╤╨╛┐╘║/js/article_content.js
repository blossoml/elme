
//全局变量，动态的文章ID
var ShareURL = "";
var iOrder="";
//绑定所有分享按钮所在A标签的鼠标移入事件，从而获取动态ID
$(function () {
    $(".bdsharebuttonbox a").mouseover(function () {
        ShareURL = $(this).attr("data-url");
    });
    
	template.config("escape", false); 
	LoadData();
	LoadDatalist();
});
/* 
* 动态设置百度分享URL的函数,具体参数
* cmd为分享目标id,此id指的是插件中分析按钮的ID
*，我们自己的文章ID要通过全局变量获取
* config为当前设置，返回值为更新后的设置。
*/
function SetShareUrl(cmd, config) {            
    if (ShareURL) {
        config.bdUrl = ShareURL;    
    }
    return config;
}

//插件的配置部分，注意要记得设置onBeforeClick事件，主要用于获取动态的文章ID
window._bd_share_config = {
    "common": {
        onBeforeClick: SetShareUrl, "bdSnsKey": {}, "bdText": ""
        , "bdMini": "2", "bdMiniList": false, "bdPic": "http://assets.jq22.com/plugin/2017-05-24-18-14-49.png", "bdStyle": "0", "bdSize": "24"
    }, "share": {}
};
//插件的JS加载部分
with (document) 0[(getElementsByTagName('head')[0] || body)
    .appendChild(createElement('script'))
    .src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='
    + ~(-new Date() / 36e5)];



//function LoadData(){
//	ID=gp.request.sArticleID;
//	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleInfo", {ID:ID,iOrder:iOrder}, function (result) {
//		if (result && result.IsSucceed) {
//			var data = result.Data;
//			if (data) {	
//				iOrder= data.iOrder;
//				BindArticlenrDom(data);
//			}
//			InitHomeCss();
//			
//			$("#prev_xy").click(LoadPrev);
//			$("#next_xy").click(LoadNext);
//		}
//		
//	});
//}

function LoadData(){
	ID=gp.request.sArticleID;
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleInfo", {ID:ID,iOrder:iOrder}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {	
				iOrder= data.iOrder;
				//获取当前页数据
				AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticle", {iOrder:iOrder,ArticleType:gp.request.ArticleType}, function (result) {
					if (result && result.IsSucceed) {
						var data = result.Data;
						if (data) {	
							var middle =null;
							var left =null;
							var right =null;
							if (data.list&& data.list.length > 0) {
								for(var i=0;i<data.list.length;i++)
								{
									switch(data.list[i].info)
									{
										case "middle":
											middle=data.list[i];
											break;
										case "left":
											left=data.list[i];
											break;
										case "right":
											right=data.list[i];
											break;
									}
			
								}
								if(middle)
								{
									iOrder=middle.iOrder;
									//$("#next_xy").removeAttr("disabled");
								}
								if(!left)
								{
									$("#prev_xy").attr('disabled',"true");
								}
								if(!right)
								{
									$("#next_xy").attr('disabled',"true");
								}
								BindArticlenrDom(middle);
							}
						}
					}
				});
				//BindArticlenrDom(data);
			}
			
			InitHomeCss();
			
			$("#prev_xy").click(LoadPrev);
			$("#next_xy").click(LoadNext);
		}
		
	});
}


function LoadPrev(){     
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticlePrevious", {ID:gp.request.sArticleID,iOrder:iOrder,ArticleType:gp.request.ArticleType}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {	
				var current=null;
				var next=null;
				var previous=null;
				if (data.list&& data.list.length > 0) {
					for(var i=0;i<data.list.length;i++)
					{
						switch(data.list[i].info)
						{
							case "current":
								current=data.list[i];
								break;
							case "previous":
								previous=data.list[i];
								break;
							case "next":
								next=data.list[i];
								break;
						}
//						if(data.list[i].info=="current")
//						{
//							current=data.list[i];
//						}
					}
					if(current)
					{
						iOrder=current.iOrder;
						$("#next_xy").removeAttr("disabled");
					}
					if(!next)
					{
						//alert("当前为第一页");
						$("#prev_xy").attr('disabled',"true");
					}
					BindArticlenrDom(current);
				}
			}
			InitHomeCss();
            $('html,body').animate({'scrollTop':0},300);
		}
	});
}
function LoadNext(){     
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleNext", {ID:gp.request.sArticleID,iOrder:iOrder,ArticleType:gp.request.ArticleType}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {	
				var current=null;
				var next=null;
				var previous=null;
				if (data.list&& data.list.length > 0) {
					for(var i=0;i<data.list.length;i++)//循环data.list数组
					{
						switch(data.list[i].info)
						{
							case "current":
								current=data.list[i];
								break;
							case "previous":
								previous=data.list[i];
								break;
							case "next":
								next=data.list[i];
								break;
						}
//						if(data.list[i].info=="current")//找到当前页的编码
//						{
//							current=data.list[i];//
//						}

					}
					if(current)
					{
						iOrder=current.iOrder;
						$("#prev_xy").removeAttr("disabled");
					}
					if(!next)
					{
						//alert("当前为最后一页");
						$("#next_xy").attr('disabled',"true");
					}
					
					BindArticlenrDom(current);
				}
			}
			InitHomeCss();
			$('html,body').animate({'scrollTop':0},300);

		}
	});
}
function LoadDatalist(){
	ArticleType=gp.request.ArticleType;
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleList", {ArticleType:ArticleType}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {				
				if (data.list && data.list.length > 0) {

					BindArticlelstDom(data.list.slice(0,5));
				}
			}
	
		}
		InitHomeCss();
		
	});
}


/**
 * 绑定产业报告详情页内容
 * @param {array 产业报告详情页内容} artcle 
 */

function BindArticlenrDom(artcle) {
	var template_html="";
	template_html = template("article_nr_template", { artcle: artcle });
	$('#article_nr_dom').html(template_html);
}

/**
 * 绑定产业报告详情页
 * @param {array 产业报告详情页} aboutlist 
 */
function BindArticlelstDom(articlelist) {
	var template_html="";
	template_html = template("article_lists_template", { articlelist: articlelist });
	$('#article_lists_dom').html(template_html);
}

/** 
 * 初始化页面 Css 样式
*/
function InitHomeCss(){
	//控制标题文字多少
	$(".article_xgtj_list .xgtj_list_zt").each(function(){
		var maxwidth=12;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
}

//转化时间格式
template.helper('dateFormat', function (date, format) {
    return $.tools.formatJsonDate(date,format);
});



