$(function(){
	$(".zzkj_nr li").hover(function(){
		$(this).css({'background-color':'#047f42','opacity':'0.99'});
		$("h2 ,div",this).css('color','#fff');
	},function(){
		$(".zzkj_nr_li h2").css('color','#333');
		$(".zzkj_nr_li div").css('color','#666');
		$(this).css({'background':'#f5f5f5 ','opacity':'1'});
	});
	
	$(".zj_tp li ").click(function(){
		$(this).find(".tp_zzc").hide().parents("li").siblings("li").find(".tp_zzc").show();
		var index = $(this).index();
		$(".zjjy_nr li").eq(index).show().siblings().hide();
	}) 
	$(".zj_tp li").hover(function() {
		$(this).find("img").stop().animate({"width":310,"height":412,"left":-15,"top":-15});
	}, function() {
		$(this).find("img").stop().animate({"width":280,"height":382,"left":0,"top":0});
	})
})







