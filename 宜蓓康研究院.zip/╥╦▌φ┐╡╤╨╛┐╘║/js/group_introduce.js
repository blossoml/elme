$(function(){
	template.config("escape", false); 
	LoadData();
})

var pageNumber=1;//当前页码
var pageSize=6;//每页多少条
var maxcount; //总条数
var totalPage; //总页数


function LoadData(){

	AjaxPost("http://wb.e100com.com/Api/Research/TeamPerson/LoadList", {pageNumber:pageNumber, pageSize:pageSize}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {				
				if (data.list && data.list.length > 0) {
					maxcount=data.list[0].maxcount;
					totalPage = Math.ceil(maxcount / pageSize);
					BindTeamListDom(data.list);
				}
			}
	
		}
		InitHomeCss();
		page();
	});
	
}
function page(){
	//分页
	$("#page").paging({
		pageNo: pageNumber,//当前页码
		totalPage: totalPage,//总页数
		totalSize: maxcount, //总条数
		callback: function(num) {
			pageNumber=num;
			LoadData();
		}
	})
}


/**
 * 团队介绍列表开始
 * @param {array 团队介绍} teamlists 
 */
function BindTeamListDom(teamlists) {
	var template_html="";
	template_html = template("team_list_template", { teamlists: teamlists });
	$('#team_list_dom').html(template_html);
}

/** 
 * 初始化页面 Css 样式
*/
function InitHomeCss(){
	//团队图片
    $('.team_list li').hover(function(){
    	$(this).stop().animate({
			bottom:'5',
		},300);
		$('.dixian',this).stop().css('height','3px');
		$('.dixian',this).stop().animate({
			left:'0',
			width:'100%',
			right:'0'
		},300);
		$(this).css("box-shadow", "0 0 10px 1px #ddd");
	},function(){
		$(this).css("box-shadow", "0 0 0");
    	$(this).stop().animate({
			bottom:'0',
		},300);
		$('.dixian',this).stop().animate({
			left:'0',
			width:'0'
		},300);
	});	
	
	//点击跳转到详情页面
//	$(".team_list li a").click(function(){
//		window.location.href="group_xq.html";
//	})	
	//控制我们的团队文字多少
	$(".dd_jieshao span").each(function(){
		var maxwidth=27;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
}
