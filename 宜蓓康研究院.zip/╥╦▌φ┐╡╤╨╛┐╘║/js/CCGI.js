$(function(){
	$(".ltzj_list li").hover(function() {
		$(this).find("img").stop().animate({"width":300,"height":295,"left":-12,"top":-10});
		$(this).find(".tp_zzc").css("display","block");
	}, function() {
		$(this).find("img").stop().animate({"width":276,"height":275,"left":0,"top":0});
		$(this).find(".tp_zzc").css("display","none");
	});
	
	jctjlb();
	tanchu();
 })

//精彩图集轮播开始
function jctjlb(){
	var i = 0;
	var timer;
	$(function () {
	    //$(".zj_photo li").eq(0).show().siblings().hide();//第一张图片显示 其余的图片隐藏
	       mStrat();
	    $(".jctj_photo li").hover(function () {//鼠标移上去之后
	        clearInterval(timer);//停止计时器
//	        i=$(this).index();//获取当前鼠标放上去的下标
//	        Show();
	    }, function () {//鼠标离开之后
	        mStrat();
	    });
	    $(".og_prev").click(function () {//点击左箭头的时候执行的事件
	        clearInterval(timer);//停止计时器
	        i--;
	        if (i == -1) {
	            i = 5;
	        }
	        prShow();
	        mStrat();  
	    });
	    $(".og_next").click(function () {
	        clearInterval(timer);//停止计时器
	        i++;
	        if (i == 6) {
	            i = 0;
	        }
	        Show();
	        mStrat();
	    });
	});
	
	function Show() {
	    $(".jctj_photo").stop(true,true).animate({marginLeft:"-327px"},500, function () {  
            $(".jctj_photo>li").eq(0).appendTo($(".jctj_photo"));  //把ul的第一个子元素添加到开头第一个
            $(".jctj_photo").css('marginLeft','0px');  
       });
	}
	function prShow() {
	    $(".jctj_photo").stop(true,true).animate({marginLeft:"0"},500, function () {  
            $(".jctj_photo").children().last().prependTo($(".jctj_photo"));  //把ul的最后一个子元素添加到开头第一个
            $(".jctj_photo").css('marginLeft','-327px');  //初始化把ul的marginleft左移327
       });
	}
	function mStrat() {
	    timer = setInterval(function () {//计时器 间隔3秒针 执行下一张图片
	        i++;
	        if (i == 6) {
	            i = 0;
	        }
	        Show();
	    }, 3000);
	}
}
//精彩图集轮播结束
//精彩图集点击弹出大图开始
function tanchu(){
	var _img =$(".jctj_photo li img");
	var _index;
	$.each(_img,function(index,item){
		console.log(item);
		$(".content_img").append('<li data-id="'+$(item).attr("index")+'"><img src="'+$(item).attr("src")+'"/></li> ');
	})
	//单击图片出现弹层
	$(".jctj_photo li img").click(function() {
		//var _src = $(this).attr("src");
		_index = $(this).attr("index");
		$(".back").show();
		showImg(_index);
		//$(".content-img li").eq(_index).show().siblings("li").hide();
		//$(".content-img").html('<li data-id="0"><img src="'+_src+'"/></li> ');
	});
	//单击关闭弹层消失
	$(".close_btn").click(function() {
		$(".back").hide();
	});
	//左按钮
	$(".dt_prev").click(function() {
		if(_index == 0){
			_index=_img.length -1;
			showImg(_index);
		}else {
			showImg(--_index);
		}
	});
	//右按钮
	$(".dt_next").click(function() {
		if(_index == _img.length -1){
			_index= 0;
			showImg(_index);
		}else {
			showImg(++_index);
		}
	});
	$(".close_btn").hover(function(){
		$(".close_btn img").attr("src","img/CCGI/Close_hover.png")
	},function(){
		$(".close_btn img").attr("src","img/CCGI/Close1.png")
	})

}
function showImg(i){
	$(".content_img li").eq(i).show().siblings("li").hide();
}
//精彩图集点击弹出大图结束


