$(function(){
	template.config("escape", false); 
	LoadData();
})

var pageNumber=1;//当前页码
var pageSize=6;//每页多少条
var maxcount; //总条数
var totalPage; //总页数

function LoadData(){
	ArticleType=gp.request.ArticleType;
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleList", {ArticleType:ArticleType, pageNumber:pageNumber, pageSize:pageSize}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {				
				if (data.list && data.list.length > 0) {
					maxcount=data.list[0].maxcount;
					totalPage = Math.ceil(maxcount / pageSize);
					BindIndustryDom(data.list);
				}
			}
	
		}
		InitHomeCss();
		page();
	});
	
}

function page(){
	//分页
	$("#page").paging({
		pageNo: pageNumber,//当前页码
		totalPage: totalPage,//总页数
		totalSize: maxcount, //总条数
		callback: function(num) {
			pageNumber=num;
			LoadData();
		}
	})
}

/**
 * 产业报告列表开始
 * @param {array 产业报告} industrylists 
 */
function BindIndustryDom(industrylists) {
	var template_html="";
	template_html = template("industrylists_template", { industrylists: industrylists });
	$('#industrylists_dom').html(template_html);
}

/** 
 * 初始化页面 Css 样式
*/
function InitHomeCss(){
	//产业报告图文
    $('.cybg_list li').hover(function(){
    	$(".cybg_title",this).stop().animate({
			bottom:'3',
		},300);
		$(".cybg_time",this).css("background-color", "#047f42");
		$(".cybg_time span",this).css("color", "#fff");
		$('.dixian',this).stop().css('height','3px');
		$('.dixian',this).stop().animate({
			left:'0',
			width:'100%',
			right:'0'
		},300);
		$(".cybg_title",this).css("box-shadow", "0 0 10px 1px #ddd");
	},function(){
		$(".cybg_time",this).css("background-color", "#fff");
		$(".cybg_time span",this).css("color", "#666");
		$(".cybg_title",this).css("box-shadow", "0 0 0");
    	$(".cybg_title",this).stop().animate({
			bottom:'0',
		},300);
		$('.dixian',this).stop().animate({
			left:'0',
			width:'0'
		},300);
	});
	
	
	//控制标题文字多少
	$(".cybg_title_nr h3").each(function(){
		var maxwidth=30;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
	//控制内容文字多少
	$(".cybg_title_nr .cybg_title_nr").each(function(){
		var maxwidth=80;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
}



