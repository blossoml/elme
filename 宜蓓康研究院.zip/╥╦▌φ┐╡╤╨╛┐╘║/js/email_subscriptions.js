$(function(){
	$("#Mobile").blur(function(){	
		$("#Mobile").css({'outline':'none','border':'1px solid #f2f2f2'});
        $(".valid_box").hide();
	});
	$("#Email").blur(function(){	
		$("#Email").css({'outline':'none','border':'1px solid #f2f2f2'});
        $(".valid_boxs").hide();
	});
})

function checkUser(){
	var mobile = $("#Mobile").val()
    var Email = $("#Email").val()
    if(mobile == ""  ){
	    $("#Mobile").focus().css({'outline':'none','border':'1px solid #e50000'});
        //alert("您的姓名不能为空");
        $(".valid_box").show();
        return false;
    }
    if(Email == ""  ){
     	$("#Email").focus().css({'outline':'none','border':'1px solid #e50000'});
    	//alert("您的邮箱地址不能为空");
    	$(".valid_boxs").show();
        return false;
    }
        return true;
    
}








