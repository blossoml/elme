$(function(){
	template.config("escape", false); 
	LoadData();
	
	
})

function LoadData(){
	//ArticleType=gp.request.ArticleType;
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleList", {ArticleType:gp.request.ArticleType}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {				
				if (data.list && data.list.length > 0) {
					
					BindIndustryDom(data.list);
				}
			}
	
		}
		InitHomeCss();
	});
	
}

/**
 * 政策解读列表开始
 * @param {array 政策解读} industrylists 
 */
function BindIndustryDom(zcjdlist) {
	var template_html="";
	template_html = template("zcjd_list_template", { zcjdlist: zcjdlist });
	$('#zcjd_list_dom').html(template_html);
}

function InitHomeCss(){
	//控制标题文字多少
	$(".zcjd_list_nr h3").each(function(){
		var maxwidth=10;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
	$(".zcjd_list_nr div").each(function(){
		var maxwidth=32;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
	$(".zcjd_xq_btn ,.zcjd_list_nr").on("tap",function(){
		document.location.href= $(this).attr("url");
	});
	
}

