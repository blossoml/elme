$(function(){   		
	template.config("escape", false); 
	LoadData();
})

function LoadData(){

	AjaxPost("http://wb.e100com.com/Api/Research/TeamPerson/LoadList", {}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {				
				if (data.list && data.list.length > 0) {
					BindTeamListDom(data.list);
				}
			}
	
		}
		InitHomeCss();
	});
	
}
/**
 * 团队介绍列表开始
 * @param {array 团队介绍} teamlists 
 */
function BindTeamListDom(teamlists) {
	var template_html="";
	template_html = template("team_list_template", { teamlists: teamlists });
	$('#team_list_dom').html(template_html);
}


/** 
 * 初始化页面 Css 样式
*/
function InitHomeCss(){
	$(".team_xqnr").on("tap",function(){
		document.location.href= $(this).attr("url");
	});
	
	$(".cpbg_title_nr").each(function(){
		var maxwidth=26;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
	
	$(".dd_jieshao span").each(function(){
		var maxwidth=15;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	})
}