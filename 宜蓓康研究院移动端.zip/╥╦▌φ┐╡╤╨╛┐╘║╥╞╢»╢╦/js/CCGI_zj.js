$(function(){
	$(".xuanzhe_mc>li>a").on("click",function () {
        $(this).addClass("active").parent("li").siblings("li").children().removeClass("active"); //切换选中的按钮高亮状态
              
    });
	$(".xuanzhe_mc>li ").on("click",function () {
        var index = $(this).index(); //获取被按下按钮的索引值，需要注意index是从0开始的 
        $(".zjxq .zjxq_nr").eq(index).show().siblings().hide();//在按钮选中时在下面显示相应的内容，同时隐藏不需要的框架内容   

	});      
 })