 
 //判断是PC端还是移动端
	if(/Android|webOS|iPhone|iPad|BlackBerry/i.test(navigator.userAgent)) {
	    //window.location.href = "http://wap.ebicomresearch.com/";
	} else {
	    window.location.href = "http://www.ebicomresearch.com/";
	}
   
 $(function(){
 	if (window != top) {
            top.location.href = location.href;
        }
	//左侧菜单链接
 	$("#offCanvasSide li").on("tap",function(){
		document.location.href= $(this).attr("url");

	});
	//点击微博图标，进入微博页面
	$(".contact_nr_tb .webo_tp").on("tap",function(){
		document.location.href= $(this).attr("url");
	});
	//点击QQ图标，进入QQ聊天页面
	$(".contact_nr_tb .qq_tp").on("tap",function(){
		document.location.href= $(this).attr("url");
	});
	
	//点击微信图标，弹出二维码
	$(".weixin_tp").on("tap",function(){
		$(".erweima").show();
	});
	$(".erweima").on("tap",function(){
		$(".erweima").hide();
	});

	
	mui.init({
				swipeBack: false,
			});
	//主界面和侧滑菜单界面均支持区域滚动；
			mui('#offCanvasSideScroll').scroll();
			mui('#offCanvasContentScroll').scroll();
			 //实现ios平台的侧滑关闭页面；
			if (mui.os.plus && mui.os.ios) {
				offCanvasWrapper[0].addEventListener('shown', function(e) { //菜单显示完成事件
					plus.webview.currentWebview().setStyle({
						'popGesture': 'none'
					});
				});
				offCanvasWrapper[0].addEventListener('hidden', function(e) { //菜单关闭完成事件
					plus.webview.currentWebview().setStyle({
						'popGesture': 'close'
					});
				});
			}
 });




