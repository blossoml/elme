$(function(){
	var _img =$(".jctj_ul li img");
	var _index;
//	$.each(_img,function(index,item){
//		console.log(item);
//		$(".content_img").append('<li data-id="'+$(item).attr("index")+'"><img src="'+$(item).attr("src")+'"/></li> ');
//	})
	//单击图片出现弹层
	$(".jctj_ul li img").on("tap",function() {
		//var _src = $(this).attr("src");
		_index = $(this).attr("index");
		$(".back").show();
		showImg(_index);
		//$(".content-img li").eq(_index).show().siblings("li").hide();
		//$(".content-img").html('<li data-id="0"><img src="'+_src+'"/></li> ');
	});
	//单击关闭弹层消失
	$(".close_btn").on("tap",function() {
		$(".back").hide();
	});
	
 })


//精彩图集点击弹出大图开始

function showImg(i){
	$(".content_img li").eq(i).show().siblings("li").hide();
}
//精彩图集点击弹出大图结束


