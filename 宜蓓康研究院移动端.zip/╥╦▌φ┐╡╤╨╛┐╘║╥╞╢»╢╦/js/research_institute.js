$(function(){
	mui.init();
	//左侧菜单链接
	var gallery = mui('.mui-slider');
		gallery.slider({
		  	interval:3000//自动轮播周期，若为0则不自动播放，默认为0；
		});
})
