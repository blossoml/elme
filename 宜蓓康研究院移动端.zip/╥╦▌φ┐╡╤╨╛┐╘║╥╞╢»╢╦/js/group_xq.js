$(function(){
	template.config("escape", false); 
	LoadData();
})


function LoadData(){
	ID=gp.request.sArticleID;
	AjaxPost("http://wb.e100com.com/Api/Research/TeamPerson/LoadTeamPersonInfo", {ID:ID}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {		
				BindTeamxqnrDom(data);	
			}
	
		}
	});
}

/**
 * 专家介绍详情页开始
 * @param {array 团队介绍} artcle 
 */
function BindTeamxqnrDom(artcle) {
	var template_html="";
	template_html = template("zjjs_nr_template", { artcle: artcle });
	$('#zjjs_nr_dom').html(template_html);
}