 $(function(){
 	if (window != top) {
            top.location.href = location.href;
        }
 	mui.init();
	//左侧菜单链接
	var gallery = mui('.mui-slider');
		gallery.slider({
		  	interval:3000//自动轮播周期，若为0则不自动播放，默认为0；
		});
	//专家寄语点击图片大小
//	$(".zj_photo img").on("tap",function(){
//		$(this).css("width","90").parents().siblings("li").find("img").css("width","60");
//	})
		
	template.config("escape", false); 
	LoadData();
	LoadTeamData();
	
	//弹出会议层
	$(".tanchuk .guanbi_btn").on("tap",function(){
		$(".zhezhaocen , .tanchuk").hide();
	})
	$(".tanchuk img").on("tap",function(){
		document.location.href= $(this).attr("url");

	});
	
 });


function LoadData(){
	//ArticleType=gp.request.ArticleType;
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleList", {}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {				
				if (data.list && data.list.length > 0) {
					BindcpbgDom(data.list);
				}
			}
			InitHomeCss();
		}
		
		
	});
	
}

/**
 * 产业报告列表开始
 * @param {array 产业报告} cpbglists 
 */
function BindcpbgDom(cpbglists) {
	var template_html="";
	template_html = template("cpbglists_template", { cpbglists: cpbglists });
	$('#cpbglists_dom').html(template_html);
}

/** 
 * 初始化页面 Css 样式
*/
function InitHomeCss(){
	$(".cpbg_ckgd").on("tap",function(){
		document.location.href= $(this).attr("url");
	});
	$(".team_xqnr").on("tap",function(){
		document.location.href= $(this).attr("url");
	});
	
	//控制产业报告列表文字多少
	$(".cpbg_title h3").each(function(){
		var maxwidth=10;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
	$(".cpbg_title_nr").each(function(){
		var maxwidth=30;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
	
	//控制我们的团队文字多少
	$(".dd_jieshao span").each(function(){
		var maxwidth=15;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});  
}
/**
 * 团队介绍列表开始
 * @param {array 团队介绍} teamlists 
 */
function LoadTeamData(){

	AjaxPost("http://wb.e100com.com/Api/Research/TeamPerson/LoadList", {}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {				
				if (data.list && data.list.length > 0) {
					BindTeamListsDom(data.list.slice(0,4));
				}
			}
			InitHomeCss();
		}
		
	});
}

function BindTeamListsDom(teamlist) {
	var template_html="";
	template_html = template("our_team_template", { teamlist: teamlist });
	$('#our_team_dom').html(template_html);
}

/**
 * 团队介绍列表结束
 *  
 */