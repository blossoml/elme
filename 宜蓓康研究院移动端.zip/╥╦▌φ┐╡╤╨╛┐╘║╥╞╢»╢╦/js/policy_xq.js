
//全局变量，动态的文章ID
var ShareURL = "";
var iOrder="";
//绑定所有分享按钮所在A标签的鼠标移入事件，从而获取动态ID
$(function () {
    $(".bdsharebuttonbox a").mouseover(function () {
        ShareURL = $(this).attr("data-url");
    });
    template.config("escape", false); 
    
	LoadData();
	LoadDataslist();
});


function shareSina() {
	//分享到新浪微博
	var sharesinastring = 'http://service.weibo.com/share/share.php?title=' + $("#title").val() + '&url=' + $("#url").val();
	window.location.href = sharesinastring;
}
function shareQQzone(){
	var p = {
		url:location.href,
		showcount:'0',/*是否显示分享总数,显示：'1'，不显示：'0' */
		desc:'',/*默认分享理由(可选)*/
		summary:'',/*分享摘要(可选)*/
		title:'',/*分享标题(可选)*/
		site:'满艺网',/*分享来源 如：腾讯网(可选)*/
		pics:'', /*分享图片的路径(可选)*/
		style:'203',
		width:98,
		height:22
	};
	//分享到QQ空间
	var sharesinastring = 'http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?title=' + $("#title").val() + '&url=' + $("#url").val() + '&site="满艺网"';
	window.location.href = sharesinastring;
}

/* 
* 动态设置百度分享URL的函数,具体参数
* cmd为分享目标id,此id指的是插件中分析按钮的ID
*，我们自己的文章ID要通过全局变量获取
* config为当前设置，返回值为更新后的设置。
*/
function SetShareUrl(cmd, config) {            
    if (ShareURL) {
        config.bdUrl = ShareURL;    
    }
    return config;
}

//插件的配置部分，注意要记得设置onBeforeClick事件，主要用于获取动态的文章ID
window._bd_share_config = {
    "common": {
        onBeforeClick: SetShareUrl, "bdSnsKey": {}, "bdText": ""
        , "bdMini": "2", "bdMiniList": false, "bdPic": "http://assets.jq22.com/plugin/2017-05-24-18-14-49.png", "bdStyle": "0", "bdSize": "24"
    }, "share": {}
};
//插件的JS加载部分
with (document) 0[(getElementsByTagName('head')[0] || body)
    .appendChild(createElement('script'))
    .src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='
    + ~(-new Date() / 36e5)];

//转化时间格式
template.helper('dateFormat', function (date, format) {
    return $.tools.formatJsonDate(date,format);
});


function LoadData(){
	ID=gp.request.sArticleID;
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleInfo", {ID:ID,iOrder:iOrder}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {	
				iOrder= data.iOrder;
				
				AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticle", {iOrder:iOrder,ArticleType:gp.request.ArticleType}, function (result) {
					if (result && result.IsSucceed) {
						var data = result.Data;
						if (data) {	
							var middle =null;
							var left =null;
							var right =null;
							if (data.list&& data.list.length > 0) {
								for(var i=0;i<data.list.length;i++)
								{
									switch(data.list[i].info)
									{
										case "middle":
											middle=data.list[i];
											break;
										case "left":
											left=data.list[i];
											break;
										case "right":
											right=data.list[i];
											break;
									}
			
								}
								if(middle)
								{
									iOrder=middle.iOrder;
									//$("#next_xy").removeAttr("disabled");
								}
								if(!left)
								{
									$("#prev_xy").attr('disabled',"true");
								}
								if(!right)
								{
									$("#next_xy").attr('disabled',"true");
								}
								BindArticlenrDom(middle);
							}
						}
					}
				});
				
			}
			
			InitHomeCss();
			
			$("#prev_xy").on("tap",function(){
				LoadPrev();
			});
			$("#next_xy").on("tap",function(){
				LoadNext();
			});
		}
		
	});
}

function LoadPrev(){     
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticlePrevious", {iOrder:iOrder,ArticleType:gp.request.ArticleType}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {	
				var current=null;
				var next=null;
				var previous=null;
				if (data.list&& data.list.length > 0) {
					for(var i=0;i<data.list.length;i++)
					{
						switch(data.list[i].info)
						{
							case "current":
								current=data.list[i];
								break;
							case "previous":
								previous=data.list[i];
								break;
							case "next":
								next=data.list[i];
								break;
						}
						if(data.list[i].info=="current")
						{
							current=data.list[i];
						}
					}
					if(current)
					{
						iOrder=current.iOrder;
						$("#next_xy").removeAttr("disabled");
					}
					if(!next)
					{
						//alert("当前为第一页");
						$("#prev_xy").attr('disabled',"true");
					}
					BindArticlenrDom(current);
				}
			}
			InitHomeCss();
			$('html,body').animate({'scrollTop':0},300);
		}
	});
}
function LoadNext(){     
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleNext", {iOrder:iOrder,ArticleType:gp.request.ArticleType}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {	
				var current=null;
				var next=null;
				var previous=null;
				if (data.list&& data.list.length > 0) {
					for(var i=0;i<data.list.length;i++)//循环data.list数组
					{
						switch(data.list[i].info)
						{
							case "current":
								current=data.list[i];
								break;
							case "previous":
								previous=data.list[i];
								break;
							case "next":
								next=data.list[i];
								break;
						}
						if(data.list[i].info=="current")//找到当前页的编码
						{
							current=data.list[i];//
						}

					}
					if(current)
					{
						iOrder=current.iOrder;
						$("#prev_xy").removeAttr("disabled");
					}
					if(!next)
					{
						//alert("当前为最后一页");
						$("#next_xy").attr('disabled',"true");
					}
					
					BindArticlenrDom(current);
				}
			}
			InitHomeCss();
			$('html,body').animate({'scrollTop':0},300);
		}
	});
}
function LoadDataslist(){
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleList", {ArticleType:gp.request.ArticleType}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {				
				if (data.list && data.list.length > 0) {
					BindArticlelstDom(data.list.slice(0,5));
				}
			}
	
		}
		InitHomeCss();
		
	});
}



/**
 * 绑定产业报告详情页内容
 * @param {array 产业报告详情页内容} artcle 
 */

function BindArticlenrDom(artcle) {
	var template_html="";
	template_html = template("policy_nr_template", { artcle: artcle });
	$('#policy_nr_dom').html(template_html);
}

/**
 * 绑定产业报告详情页
 * @param {array 产业报告详情页} articlelist 
 */
function BindArticlelstDom(policylist) {
	var template_html="";
	template_html = template("policy_lists_template", { policylist: policylist });
	$('#policy_lists_dom').html(template_html);
}

/** 
 * 初始化页面 Css 样式
*/
function InitHomeCss(){
	//控制标题文字多少
	$(".article_xgtj_list .xgtj_list_zt").each(function(){
		var maxwidth=15;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
	$(".article_lists_template").on("tap",function(){
		document.location.href= $(this).attr("url");
	});
	$(".bgqwxz a").on("tap",function(){
		document.location.href= $(this).attr("url");
	});
	//点击微信图标，弹出二维码
	$(".gb_resItms .bds_weixin").on("tap",function(){
		$(".erweimas").show();
	});
	$(".erweimas").on("tap",function(){
		$(".erweimas").hide();
	});
	//点击QQ图标，进入QQ聊天页面
	$(".gb_resItms .bds_qzone").on("tap",function(){
		shareQQzone();
		//document.location.href= $(this).attr("url");
	});
	//点击微博图标，进入微博页面
	$(".gb_resItms .bds_tsina").on("tap",function(){
		shareSina();
	});
}

function shareSina() {
	//分享到新浪微博
	var sharesinastring = 'http://service.weibo.com/share/share.php?title=' + $("#title").val() + '&url=' + $("#url").val();
	window.location.href = sharesinastring;
}
function shareQQzone(){
	var p = {
		url:location.href,
		showcount:'0',/*是否显示分享总数,显示：'1'，不显示：'0' */
		desc:'',/*默认分享理由(可选)*/
		summary:'',/*分享摘要(可选)*/
		title:'',/*分享标题(可选)*/
		site:'满艺网',/*分享来源 如：腾讯网(可选)*/
		pics:'', /*分享图片的路径(可选)*/
		style:'203',
		width:98,
		height:22
	};
	//分享到QQ空间
	var sharesinastring = 'http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?title=' + $("#title").val() + '&url=' + $("#url").val() + '&site="满艺网"';
	window.location.href = sharesinastring;
}



/* 
* 动态设置百度分享URL的函数,具体参数
* cmd为分享目标id,此id指的是插件中分析按钮的ID
*，我们自己的文章ID要通过全局变量获取
* config为当前设置，返回值为更新后的设置。
*/
function SetShareUrl(cmd, config) {            
    if (ShareURL) {
        config.bdUrl = ShareURL;    
    }
    return config;
}

//插件的配置部分，注意要记得设置onBeforeClick事件，主要用于获取动态的文章ID
window._bd_share_config = {
    "common": {
        onBeforeClick: SetShareUrl, "bdSnsKey": {}, "bdText": ""
        , "bdMini": "2", "bdMiniList": false, "bdPic": "http://assets.jq22.com/plugin/2017-05-24-18-14-49.png", "bdStyle": "0", "bdSize": "24"
    }, "share": {}
};
//插件的JS加载部分
with (document) 0[(getElementsByTagName('head')[0] || body)
    .appendChild(createElement('script'))
    .src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='
    + ~(-new Date() / 36e5)];

//转化时间格式
template.helper('dateFormat', function (date, format) {
    return $.tools.formatJsonDate(date,format);
});


