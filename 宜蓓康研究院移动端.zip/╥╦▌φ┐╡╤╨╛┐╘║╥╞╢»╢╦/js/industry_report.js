$(function(){
	template.config("escape", false); 
	LoadData();
	
	
})

function LoadData(){
	ArticleType=gp.request.ArticleType;
	AjaxPost("http://wb.e100com.com/Api/Research/ResearchArticle/LoadResearchArticleList", {ArticleType:ArticleType}, function (result) {
		if (result && result.IsSucceed) {
			var data = result.Data;
			if (data) {				
				if (data.list && data.list.length > 0) {
					
					BindIndustryDom(data.list);
				}
			}
	
		}
		InitHomeCss();
		
	});
	
}

/**
 * 产业报告列表开始
 * @param {array 产业报告} industrylists 
 */
function BindIndustryDom(industrylists) {
	var template_html="";
	template_html = template("industrylists_template", { industrylists: industrylists });
	$('#industrylists_dom').html(template_html);
}

function InitHomeCss(){
	//控制标题文字多少
	$(".zcjd_list_nr h3").each(function(){
		var maxwidth=12;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
	$(".zcjd_list_nr div").each(function(){
		var maxwidth=32;
		if($(this).text().length>maxwidth){
			$(this).text($(this).text().substring(0,maxwidth));
			$(this).html($(this).html()+"...");
		}
	});
	$(".zcjd_list_nr").on("tap",function(){
		document.location.href= $(this).attr("url");
	});
}




