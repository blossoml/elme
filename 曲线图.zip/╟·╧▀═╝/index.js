﻿$(function(){
    var myChart=null;
    var myChart1=null;
    var myChart2=null;
    option = {  
       /* grid: {
            borderColor: '#eee',
                x:86,
                y:46,    
                x2:86,  
                y2:66,              
                borderWidth:1      
        },   */

        tooltip: {
            trigger: "item",
            formatter: "{c}",
            backgroundColor: '#138F51',     // 提示背景颜色，默认为透明度为0.7的黑色
            axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                type : 'line',         // 默认为直线，可选为：'line' | 'shadow'
                lineStyle : {          // 直线指示器样式设置
                    color: '#008acd'
                },
                crossStyle: {
                    color: '#008acd'
                },
                shadowStyle : {                     // 阴影指示器样式设置
                    color: 'rgba(200,200,200,0.2)'
                }
            }
        },        
        legend: {
            x: 'left',
            data:[''] /*图例内容数组*/
        },        
        xAxis: [{ 
        type : 'category',
        axisLine: {            // 坐标轴线
                lineStyle: {       // 属性lineStyle控制线条样式
                    color: '#E4E4E4',
                    width:1,               
                }
            },
            splitArea : {
                show : false,
                areaStyle : {
                    color: ['#fff','#fff']
                }
            },
            splitLine: {  
                show:false,       //控制网格颜色
                lineStyle: {      
                    color: ['#E4E4E4']
                }
            }     
    　　}],
        yAxis: [{    

        type:"log", 
            axisLine: {            // 坐标轴线
                lineStyle: {       // 属性lineStyle控制线条样式
                    color: '#E4E4E4',
                    width:1,    
                }
            }, 
            splitLine: {       //控制网格颜色      
                lineStyle: {       
                    color: ['#E4E4E4']
                }
            },                     
        }],   
        series: [{         
                type: "line",          
                smooth : true,
                symbol: 'circle',  // 拐点图形类型
                symbolSize: [3,10],          // 拐点图形大小,
                itemStyle: {
                    normal: {
                        color: '#138F51',      // 阳线填充颜色
                        lineStyle: {
                            color: '#138F51' ,
                                 width:4
                        }
                    }
                },               
                markLine : {
                    data : [                                  
                    ],
                    itemStyle: {
                        normal: {
                            color: '#138F51',      // 阳线填充颜色
                            lineStyle: {
                                color: '#138F51',
                          
                            }
                        }
                    },  
                },                
            }
        ]
    };
    //require(['./macarons'],function(theme){};
    
  $(".canvas_w").each(function (index) { 
   
    var  myChart = echarts.init(document.getElementsByClassName("canvas_w")[index]);
    var xarr = [12,15,34,46];
    var yarr = [12,undefined,12,45];

    option.yAxis[0].axisLabel = {};
  
     option.xAxis[0].data = xarr;
     option.series[0].data = yarr;

    myChart.setOption(option);
  })
    window.addEventListener("resize",function(){
        
    })    
    /*侧边栏目滚动代码*/ 
    var win = $(window);
    var winH = $(window).height();
    var r = $(".outer_wrap");
    var left = $(".daohang");
    var la = $(".daohang a");
    var rightH = left.height();
    var t = $('html,body');
    var canvasW = r.find('.canvas_w');
    var positionY=[];    
    /*存储导航a的位置*/
    la.each(function(){
     positionY.push($(this).position().top);
    })
    /*点击导航右侧边栏目滚动*/
    $(".daohang").on("click","a",function(){ 
        $(this).addClass("active").siblings().removeClass("active");       
        var id="#"+$(this).data("id");        
        t.animate({scrollTop:$(id).offset().top},400); 
    })  
    win.on("scroll",function(e){
        canvasW.each(function(i){
            var top=$(this).offset().top;            
            if (Math.abs(top - t.scrollTop()) < 50) {               
                $(la[i]).addClass("active").siblings().removeClass("active");               
                left.scrollTop(positionY[i]);
            }
        })
    }) 
})